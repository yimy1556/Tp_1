#include "lista.h"
#include <stdlib.h>
#include <stdio.h>
#define INICIO 0

typedef struct nodo{
    void* dato;
    struct nodo* siguiente_nodo;
}nodo_t;

struct lista{
    nodo_t* primer_nodo;
    nodo_t* ultimo_nodo;
    size_t largo;
};

struct lista_iter{
    nodo_t* actual;
    nodo_t* anterior;
    lista_t* lista;
};

lista_t* lista_crear(){
    lista_t* lista = malloc(sizeof(lista_t)); 
    if (!lista) return NULL;
    lista->primer_nodo = NULL;
    lista->ultimo_nodo = NULL;
    lista->largo = INICIO;
    return lista;
}

nodo_t* nodo_crear(void* dato ,nodo_t* direccion){
    nodo_t* nuevo_nodo = malloc(sizeof(nodo_t));    
    if(!nuevo_nodo) return NULL;
    nuevo_nodo->dato = dato;
    nuevo_nodo->siguiente_nodo = direccion;
    return nuevo_nodo;
}

void nodo_destruir(nodo_t* nodo){
    free(nodo);
}

bool lista_esta_vacia(const lista_t* lista){
    return !lista->primer_nodo;
}

bool lista_insertar_primero(lista_t* lista ,void* dato){
    nodo_t* nodo = nodo_crear(dato ,lista->primer_nodo);
    if(!nodo) return false;
    if(lista_esta_vacia(lista)) lista->ultimo_nodo = nodo;
    lista->primer_nodo = nodo;
    lista->largo++;
    return true;
}

bool lista_insertar_ultimo(lista_t* lista ,void* dato){
    if(lista_esta_vacia(lista)) return lista_insertar_primero(lista ,dato);
    nodo_t* nodo = nodo_crear(dato,NULL);
    if(!nodo) return false;
    lista->ultimo_nodo->siguiente_nodo = nodo;
    lista->ultimo_nodo = nodo;
    lista->largo++;
    return true;    
}

void* lista_borrar_primero(lista_t* lista){
    if (lista_esta_vacia(lista)) return NULL; 
    void* dato_1 = lista_ver_primero(lista);                
    nodo_t* direccion_aux = lista->primer_nodo->siguiente_nodo;    
    nodo_destruir(lista->primer_nodo);
    lista->primer_nodo = direccion_aux;
    lista->largo--;
    if (lista_esta_vacia(lista)) lista->ultimo_nodo = NULL;
    return dato_1;
} 

void* lista_ver_primero(const lista_t* lista){
    return (lista_esta_vacia(lista))? NULL:lista->primer_nodo->dato;
}

void* lista_ver_ultimo(const lista_t* lista){
    return (lista_esta_vacia(lista))? NULL:lista->ultimo_nodo->dato;
}

size_t lista_largo(const lista_t* lista){
    return lista->largo;
}

void lista_destruir(lista_t* lista,void destruir_dato(void*)){
    void* dato;
    while(!lista_esta_vacia(lista)){
        dato = lista_borrar_primero(lista);
        if (destruir_dato) destruir_dato(dato);        
    }
    free(lista);
}

//########primitivas de iterador externo
lista_iter_t* lista_iter_crear(lista_t* lista){
    lista_iter_t* lista_iter = malloc(sizeof(lista_iter_t));
    if (!lista_iter) return NULL;
    lista_iter->actual =  lista->primer_nodo;
    lista_iter->anterior = NULL;
    lista_iter->lista = lista;
    return lista_iter;
}

bool lista_iter_avanzar(lista_iter_t* iter){
    if (!iter->actual) return false;
    iter->anterior = iter->actual;
    iter->actual = iter->actual->siguiente_nodo;
    return true;    
}
void* lista_iter_ver_actual(const lista_iter_t* iter){
    return (!iter->actual)? NULL:iter->actual->dato;
}

bool lista_iter_al_final(const lista_iter_t* iter){
    return !iter->actual;
}

void lista_iter_destruir(lista_iter_t* iter){
    free(iter);
}

bool lista_iter_insertar(lista_iter_t* iter ,void* dato){
    nodo_t* nuevo_nodo = nodo_crear(dato, iter->actual);
    if(!nuevo_nodo) return false;
    if(!iter->actual) iter->lista->ultimo_nodo = nuevo_nodo;
    if(!iter->anterior) iter->lista->primer_nodo = nuevo_nodo;
    iter->actual = nuevo_nodo;
    if(iter->anterior) iter->anterior->siguiente_nodo = nuevo_nodo;
    iter->lista->largo++; 
    return true;
}

void* lista_iter_borrar(lista_iter_t* iter){
    if(!lista_iter_ver_actual(iter)) return NULL;
    void* dato = lista_iter_ver_actual(iter);
    nodo_t* siguiente_nodo = iter->actual->siguiente_nodo; 
    if(iter->actual == iter->lista->primer_nodo) lista_borrar_primero(iter->lista);
    else{
        iter->anterior->siguiente_nodo = siguiente_nodo;
        if(iter->actual == iter->lista->ultimo_nodo) iter->lista->ultimo_nodo = iter->anterior;
        nodo_destruir(iter->actual); 
        iter->lista->largo--;
    }
    iter->actual = siguiente_nodo;
    return dato;
}

//##############primitivas del iterador interno
void lista_iterar(lista_t* lista, bool visitar(void* dato, void* extra), void* extra){
    bool continuar = true;
    nodo_t* iterar = lista->primer_nodo;
    while (iterar){
        continuar = visitar(iterar->dato,extra);
        if (!continuar) return;
        iterar = iterar->siguiente_nodo;     
    }   
}
