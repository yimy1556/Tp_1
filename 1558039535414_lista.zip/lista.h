#ifndef _LISTA_H
#define _LISTA_H
#include <stddef.h>
#include <stdbool.h>

typedef struct lista_iter lista_iter_t;

typedef struct lista lista_t;

// Crea una lista.
// Post: devuelve una nueva lista vacia.
lista_t* lista_crear(void);

// Pre: la lista fue creada.
// Post: Devuelve verdadero o falso, segun si la lista tiene o no elementos.
bool lista_esta_vacia(const lista_t* lista);


// Pre: la lista fue creada.
// Post: devuelve true si inserta un nuevo elemento al principio de la  lista
// y false en caso contrario.
bool lista_insertar_primero(lista_t* lista ,void* dato);


// Pre: la lista fue creada.
// Post: devuelve true si inserta un nuevo elemento al final de la  lista
// y false en caso contrario.
bool lista_insertar_ultimo(lista_t* lista ,void* dato);


// Pre: la lista fue creada.
// Post: devuelve el primer elemento del la lista.
// y resta 1 al largo de la lista.  
void* lista_borrar_primero(lista_t* lista);


// Pre: la lista fue creada.
// Post: devuelve el ultimo elemento de la lista y
// si la lista esta vacia devuelve NULL
void *lista_ver_primero(const lista_t *lista);


// Pre: la lista fue creada.
// Post: devuelve el ultimo elemento del la lista y
// si la lista esta vacia devuelve NULL
void *lista_ver_ultimo(const lista_t* lista);

// Pre: la lista fue creada.
// Post: devuelve el largo de la lista.
size_t lista_largo(const lista_t* lista);


// Pre: la lista fue creada.
// Post: se eliminaron todos los elementos de la lista.
void lista_destruir(lista_t *lista, void destruir_dato(void*));

//#####################primitiva del iterador interno##################################
// Pre: la lista fue creada.
//Post: Itera una posicion en la lista. La funcion de visitar recibe el 
// dato y otra dirrecion de memoria, y devuelve true si se debe seguir iterando,
// false en caso contrario.
void lista_iterar(lista_t *lista, bool visitar(void* dato, void* extra), void* extra);

//############primitiva del iterador externo###########################################

// Post: devuelve un iterador.
lista_iter_t* lista_iter_crear(lista_t* lista);

// Pre: el iterador fue creado.
// Post: devuelve true si pudo avanzar o false .
bool lista_iter_avanzar(lista_iter_t* iter);

//Pre: el iterador fue creado.
//Post: Devuelve el elemento de donde se encuentra el iterador
void* lista_iter_ver_actual(const lista_iter_t* iter);

// Pre: el iterador fue creado.
// Post: devuelve true si donde esta el iterador es NULL
// de lo contrario false.
bool lista_iter_al_final(const lista_iter_t* iter);

// Pre: el iterador fue creado.
// Post: elimina el iterador.
void lista_iter_destruir(lista_iter_t* iter);

// Pre: el iterador fue creado.
// post: iserta un elemento donde esta ubicada el iterador.
bool lista_iter_insertar(lista_iter_t* iter, void* dato);

// Pre: el iterador fue creado.
// post: borra el elemento donde esta ubicada el iterador.
void* lista_iter_borrar(lista_iter_t* iter);

#endif // _LISTA_H
