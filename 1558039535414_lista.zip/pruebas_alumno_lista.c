#include "lista.h"
#include "pila.h"
#include "testing.h"
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#define TOPE 100
#define VOLUMEN 800

void destr_pila(void* pila){
    pila_destruir((pila_t*)pila);
}

void* asignar_memoria(){
    int* var = malloc(sizeof(int));
    if (!var) return NULL;
    return var;
}


void crear_eliminar_lista(){
    lista_t* lista = lista_crear();
    print_test("la lista se creo correctamente",lista != NULL);
    lista_destruir(lista,NULL);
    print_test("la lista fue destruido",true);
}

void insertar_inicial_final(){
    lista_t* lista = lista_crear();
    int valor_1 = 78;
    char valor = 'E';
    int valor_2 = 6;
    int valor_3 = 98;
    int valor_4 = 8;
    size_t valor_5 = 937;
    int valor_6 = 33;

    print_test("insertar al inicio true",lista_insertar_primero(lista,&valor));
    print_test("insertar al inicio true",lista_insertar_primero(lista,&valor_1));
    print_test("insertar al inicio true",lista_insertar_primero(lista,&valor_2));
    
    print_test("lista largo 3",lista_largo(lista) == 3);

    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_2);
    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_1);
    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor);
    
    print_test("lista largo 3",lista_largo(lista) == 0);

    print_test("insertar al final true",lista_insertar_ultimo(lista,&valor_3));
    print_test("insertar al final true",lista_insertar_ultimo(lista,&valor_4));
    print_test("insertar al final true",lista_insertar_ultimo(lista,&valor_5));
    print_test("insertar al final true",lista_insertar_ultimo(lista,&valor_6));
    
    print_test("lista largo 4",lista_largo(lista) == 4);

    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_3);
    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_4);
    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_5);
    print_test("eliminar primero true",lista_borrar_primero(lista) == &valor_6);
 
    print_test("lista largo 3",lista_largo(lista) == 0);

    print_test("lista esta vacia true",lista_esta_vacia(lista));

    lista_destruir(lista, NULL);
    print_test("la lista fue destruido",true);

}

void insertar_inicial_final_casas_heap(){
    int* valor = asignar_memoria();
    int* valor_1 = asignar_memoria();
    int* valor_2 = asignar_memoria();
    int* valor_3 = asignar_memoria();
    lista_t* lista = lista_crear();

    print_test("lista insertar  true",lista_insertar_ultimo(lista,valor));
    print_test("lista insertar  true",lista_insertar_primero(lista,valor_1));
    print_test("lista insertar true",lista_insertar_ultimo(lista,valor_2));
    print_test("lista insertar  true",lista_insertar_primero(lista,valor_3));

    print_test("lista ver actual true",lista_ver_primero(lista) == valor_3);
    
    print_test("lista ver ultimo true",lista_ver_ultimo(lista) == valor_2);

    free(lista_borrar_primero(lista));
    print_test("lista eliminar primero",true);
    
    print_test("lista ver actual",lista_ver_primero(lista) == valor_1);

    print_test("lista esta vacia false",!lista_esta_vacia(lista));

    lista_destruir(lista ,free);
    print_test("la lista fue destruido",true);
}

void pruebas_volumen(){
    size_t vector[VOLUMEN];
    lista_t* lista = lista_crear();
    size_t cont = 0;
    bool inserto = true;
    while(cont < (VOLUMEN/2) && inserto ){
        vector[cont] = cont;
        inserto = lista_insertar_primero(lista ,&vector[cont]);        
        cont++;
    }
    print_test("se inserto correctamente desde el primero los 400 elementos",lista_largo(lista) == cont);
    print_test("el primer valor es 400",lista_ver_primero(lista) == &vector[cont-1]);

    while(cont < VOLUMEN && inserto ){
        vector[cont] = cont;
        inserto = lista_insertar_ultimo(lista ,&vector[cont]);        
        cont++;
    }
    print_test("se inserto correctamente desde el ultimo lo 400 elemento",lista_largo(lista) == VOLUMEN);
    print_test("el ultimo valor es 800",lista_ver_ultimo(lista) == &vector[cont-1]);

    lista_destruir(lista,NULL);
    print_test("lista destruida correctamente",true);
}

void pruebas_ver_primero(){
    lista_t* lista = lista_crear();
    int valor_1 = 78;
    char valor = 'E';
    int valor_2 = 6;
    int valor_3 = 98;
    int valor_4 = 8;

    print_test("lista insertar valor 78",lista_insertar_ultimo(lista ,&valor_1));
    print_test("lista insertar valor E",lista_insertar_ultimo(lista ,&valor));
    print_test("lista insertar valor 6",lista_insertar_ultimo(lista ,&valor_2));
    print_test("lista insertar valor 98",lista_insertar_ultimo(lista ,&valor_3));
    print_test("lista insertar valor 8",lista_insertar_ultimo(lista ,&valor_4));

    print_test("lista ver el primero es 78",lista_ver_primero(lista) == &valor_1);
    lista_borrar_primero(lista);
    print_test("lista ver el primero es E",lista_ver_primero(lista) == &valor);
    lista_borrar_primero(lista);
    print_test("lista ver el primero es 6",lista_ver_primero(lista) == &valor_2);
    lista_borrar_primero(lista);
    print_test("lista ver el primero es 98",lista_ver_primero(lista) == &valor_3);
    lista_borrar_primero(lista);
    print_test("lista ver el primero es 8",lista_ver_primero(lista) == &valor_4);
    lista_borrar_primero(lista);

    print_test("lista esta vacia true",lista_esta_vacia(lista));
    lista_destruir(lista ,NULL);
    print_test("lista destruida true",true);
}
void insertar_null(){
    lista_t* lista =  lista_crear();

    print_test("insertar null true",lista_insertar_primero(lista ,NULL));
    print_test("insertar null true",lista_insertar_primero(lista ,NULL));
    print_test("insertar null true",lista_insertar_ultimo(lista ,NULL));
    print_test("insertar null true",lista_insertar_ultimo(lista ,NULL));
    
    print_test("lista esta vacia  false",!lista_esta_vacia(lista));
    
    lista_destruir(lista,NULL);

    print_test("la lista fue destruido", true);
}
void insertar_iter_medio(){
    int vector[TOPE];
    lista_t* lista = lista_crear();
    
    for (int i = 0; i < TOPE; i++){
        vector[i] = i;
        lista_insertar_primero(lista,&vector[i]);
    }
    
    print_test("lista esta vacia false",!lista_esta_vacia(lista));
    
    lista_iter_t* iter = lista_iter_crear(lista); 

    for (int i = 0; i < TOPE/2;i++) {
        lista_iter_avanzar(iter);
    }
    
    print_test("lista valor actuas 50",lista_iter_ver_actual(iter) == &vector[49]);
    int valor = 70;
    print_test("lista agregar 70",lista_iter_insertar(iter ,&valor));
    
    print_test("lista ver actual es 70",lista_iter_ver_actual(iter) == &valor);

    lista_iter_destruir(iter);

    lista_destruir(lista,NULL);

    print_test("lista destruido true",true);
}


void insertar_iter_externo(){
    lista_t* lista = lista_crear();
    lista_iter_t* iter = lista_iter_crear(lista);
    int valor = 44;
    int valor_1 = 23;  
    int valor_2 = 34;
    int valor_3 = 23;  
    int valor_4 = 231;  
    int valor_5 = 454;  
    int valor_6 = 242;  
    int valor_7 = 565; 
   
    print_test("se puede desplazar false",!lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es NULL",lista_iter_ver_actual(iter) == NULL); 

    print_test("agregar elemento 44",lista_iter_insertar(iter ,&valor));
    print_test("agregar elemento 23",lista_iter_insertar(iter ,&valor_1));
    print_test("agregar elemento 34",lista_iter_insertar(iter ,&valor_2));
    print_test("agregar elemento 23",lista_iter_insertar(iter ,&valor_3));
    print_test("agregar elemento 231",lista_iter_insertar(iter ,&valor_4));
    print_test("agregar elemento 454",lista_iter_insertar(iter ,&valor_5));
    print_test("agregar elemento 242",lista_iter_insertar(iter ,&valor_6));
    print_test("agregar elemento 565",lista_iter_insertar(iter ,&valor_7));
    
    print_test("elemento actual  es 565",lista_iter_ver_actual(iter) == &valor_7); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 

    print_test("elemento actual es 242",lista_iter_ver_actual(iter) == &valor_6); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 

    print_test("elemento actual es 454",lista_iter_ver_actual(iter) == &valor_5); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es 231",lista_iter_ver_actual(iter) == &valor_4); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
  
    print_test("elemento actual es 23",lista_iter_ver_actual(iter) == &valor_3); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es 34",lista_iter_ver_actual(iter) == &valor_2);
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es 23",lista_iter_ver_actual(iter) == &valor_1); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es 44",lista_iter_ver_actual(iter) == &valor); 
    print_test("se puede desplazar false",lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es NULL",lista_iter_ver_actual(iter) == NULL); 
    print_test("se puede desplazar false",!lista_iter_avanzar(iter)); 

    lista_iter_destruir(iter);

    lista_destruir(lista ,NULL);

}


void insertar_iter_final(){
    lista_t* lista = lista_crear();
    lista_iter_t* iter = lista_iter_crear(lista);
 
    int valor = 44;
    int valor_1 = 23;  
    int valor_2 = 34;
    int valor_3 = 23;  

    print_test("se puede desplazar false",!lista_iter_avanzar(iter)); 
    
    print_test("elemento actual es NULL",lista_iter_ver_actual(iter) == NULL); 

    print_test("agregar elemento 44",lista_iter_insertar(iter ,&valor));
    print_test("agregar elemento 23",lista_iter_insertar(iter ,&valor_1));
    print_test("agregar elemento 34",lista_iter_insertar(iter ,&valor_2));
         
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    print_test("se puede desplazar true",lista_iter_avanzar(iter)); 
    print_test("se puede desplazar false",!lista_iter_avanzar(iter)); 
    
    print_test("esta en el el final true",lista_iter_al_final(iter));

    print_test("agregar elemento 23",lista_iter_insertar(iter ,&valor_3));

    print_test("esta en el final false",!lista_iter_al_final(iter));

    print_test("el valor actual es 23",lista_iter_ver_actual(iter) == &valor_3);

    print_test("se puede desplazar true",lista_iter_avanzar(iter));

    print_test("el valor del actual es NULL",lista_iter_ver_actual(iter) == NULL);

    lista_iter_destruir(iter);

    lista_destruir(lista,NULL);

    print_test("lista destruido true",true);
}
bool sumar_todos(void* dato, void* extra) {
    *(int*) extra += *(int*) dato; 
    return true;
} 
void pruebas_iter_interno(){
    lista_t* lista = lista_crear();
    int valor = 0;
    int valor_1 = 1;
    int valor_2 = 2;
    int valor_3 = 3;
    int valor_4 = 4;
    int valor_5 = 5;
    int valor_6 = 6;
    int valor_7 = 7;
    int valor_8 = 8;
    int valor_9 = 9;
    int valor_10 = 10;

    int sumar = 0;

    lista_insertar_primero(lista,&valor);
    lista_insertar_primero(lista,&valor_1);
    lista_insertar_primero(lista,&valor_2);
    lista_insertar_primero(lista,&valor_3);
    lista_insertar_primero(lista,&valor_4);
    lista_insertar_primero(lista,&valor_5);
    lista_insertar_primero(lista,&valor_6);
    lista_insertar_primero(lista,&valor_7);
    lista_insertar_primero(lista,&valor_8);
    lista_insertar_primero(lista,&valor_9);
    lista_insertar_primero(lista,&valor_10);

    lista_iterar(lista,sumar_todos,&sumar);
    
    print_test("la suma total es 55",sumar == 55);
    
    lista_destruir(lista,NULL);

    print_test("lista destruida correctamente",true);
}

void pruebas_borrar(){
    lista_t* lista = lista_crear();
    int valor = 0;
    int valor_1 = 1;
    int valor_2 = 2;
    int valor_3 = 3;
    int valor_4 = 4;
    int valor_5 = 5;
    int valor_6 = 6;
    int valor_7 = 7;
    int valor_8 = 8;
    int valor_9 = 9;
    int valor_10 = 10;

    lista_insertar_primero(lista,&valor);
    lista_insertar_primero(lista,&valor_1);
    lista_insertar_primero(lista,&valor_2);
    lista_insertar_primero(lista,&valor_3);
    lista_insertar_primero(lista,&valor_4);
    lista_insertar_primero(lista,&valor_5);
    lista_insertar_primero(lista,&valor_6);
    lista_insertar_primero(lista,&valor_7);
    lista_insertar_primero(lista,&valor_8);
    lista_insertar_primero(lista,&valor_9);
    lista_insertar_primero(lista,&valor_10);
    
    lista_iter_t* iter = lista_iter_crear(lista);
    
    lista_iter_avanzar(iter);
    lista_iter_avanzar(iter);
    lista_iter_avanzar(iter);
    lista_iter_avanzar(iter);
    lista_iter_avanzar(iter);
    
    int* im = lista_iter_ver_actual(iter);
    printf("%i\n",*im);
    print_test("el valor del actual es 5",lista_iter_ver_actual(iter) == &valor_5);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor_5);


    print_test("el valor del actual es 4",lista_iter_ver_actual(iter) == &valor_4);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor_4);


    print_test("el valor del actual es 3",lista_iter_ver_actual(iter) == &valor_3);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor_3);


    print_test("el valor del actual es 2",lista_iter_ver_actual(iter) == &valor_2);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor_2);


    print_test("el valor del actual es 1",lista_iter_ver_actual(iter) == &valor_1);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor_1);


    print_test("el valor del actual es 0",lista_iter_ver_actual(iter) == &valor);
    print_test("actual fue borrado correctamente",lista_iter_borrar(iter) == &valor);

    print_test("el valor del actual es NULL",lista_iter_ver_actual(iter) == NULL);
    print_test("actual no se borrado correctamente",!lista_iter_borrar(iter));
    
    lista_iter_destruir(iter);

    lista_destruir(lista,NULL);
}
void pruebas_lista_alumno(){ 
    crear_eliminar_lista();
    insertar_inicial_final();
    insertar_inicial_final_casas_heap();
    insertar_null();
    pruebas_ver_primero();
    pruebas_volumen();
    insertar_iter_externo(); 
    insertar_iter_final();
    insertar_iter_medio();
    pruebas_iter_interno();
    pruebas_borrar();
}
